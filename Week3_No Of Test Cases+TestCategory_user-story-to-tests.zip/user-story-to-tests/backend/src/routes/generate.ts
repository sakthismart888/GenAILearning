import express from 'express'
import { GroqClient } from '../llm/groqClient'
import { GenerateRequestSchema, GenerateResponseSchema, GenerateResponse } from '../schemas'
import { SYSTEM_PROMPT, buildPrompt } from '../prompt'

export const generateRouter = express.Router()

generateRouter.post('/', async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    // Validate request body
    const validationResult = GenerateRequestSchema.safeParse(req.body)
    
    if (!validationResult.success) {
      res.status(400).json({
        error: `Validation error: ${validationResult.error.message}`
      })
      return
    }

  const request = validationResult.data

  // Build prompts (includes categories if provided)
  const userPrompt = buildPrompt(request)

    // Create GroqClient instance here to ensure env vars are loaded
    const groqClient = new GroqClient()

    // Generate tests using Groq
    try {
      const groqResponse = await groqClient.generateTests(SYSTEM_PROMPT, userPrompt)
      
      // Parse the JSON content
      let parsedResponse: GenerateResponse
      try {
        parsedResponse = JSON.parse(groqResponse.content)
      } catch (parseError) {
        res.status(502).json({
          error: 'LLM returned invalid JSON format'
        })
        return
      }

      // Validate the response schema
      const responseValidation = GenerateResponseSchema.safeParse(parsedResponse)
      if (!responseValidation.success) {
        res.status(502).json({
          error: 'LLM response does not match expected schema'
        })
        return
      }

      // Ensure each case has a category; apply normalization map to map common synonyms to canonical categories
      const requestedCategoriesRaw = request.categories ?? []

      const normalizeMap: Record<string, string> = {
        positive: 'Positive',
        'happy path': 'Positive',
        'happy-path': 'Positive',
        smoke: 'Positive',
        negative: 'Negative',
        edge: 'Edge',
        'edge case': 'Edge',
        'edge-case': 'Edge',
        authorization: 'Authorization',
        auth: 'Authorization',
        'non-functional': 'Non-Functional',
        'non functional': 'Non-Functional',
        performance: 'Non-Functional',
        regression: 'Regression'
      }

      const normalizeCategory = (raw?: string) => {
        if (!raw) return undefined
        const key = raw.trim().toLowerCase()
        return normalizeMap[key] ?? raw
      }

      const requestedCategories = requestedCategoriesRaw.map(c => (normalizeCategory(c) ?? c).toLowerCase())

      const normalizedCases = responseValidation.data.cases.map((c) => {
        const cat = c.category ?? requestedCategoriesRaw[0] ?? 'General'
        const normalized = normalizeCategory(cat) ?? cat
        return {
          id: c.id,
          title: c.title,
          steps: c.steps,
          testData: c.testData,
          expectedResult: c.expectedResult,
          category: normalized
        }
      })

      // If the user requested specific categories, filter results to only those categories (after normalization)
      let filteredCases = normalizedCases
      if (requestedCategories.length > 0) {
        filteredCases = normalizedCases.filter(c => requestedCategories.includes((c.category || '').toLowerCase()))
        if (filteredCases.length === 0) {
          // If strict filtering removed everything, fall back to returning all generated cases but log a warning
          console.warn('Requested categories yielded no matches in LLM response; returning all generated cases')
          filteredCases = normalizedCases
        }
      }

      // Add token usage info if available and include a note when fewer cases than requested
      const requestedCount = typeof request.testcaseCount === 'number' ? request.testcaseCount : undefined

      // Prefer model-provided note if any
      const modelNote = typeof parsedResponse === 'object' && (parsedResponse as any).note ? (parsedResponse as any).note : undefined

      const finalResponse: any = {
        ...responseValidation.data,
        cases: filteredCases,
        model: groqResponse.model,
        promptTokens: groqResponse.promptTokens,
        completionTokens: groqResponse.completionTokens
      }

      if (requestedCount && filteredCases.length < requestedCount) {
        finalResponse.note = modelNote ?? `Model returned ${filteredCases.length} test case(s) but ${requestedCount} were requested.`
      } else if (modelNote) {
        finalResponse.note = modelNote
      }

      res.json(finalResponse)
    } catch (llmError) {
      console.error('LLM error:', llmError)
      res.status(502).json({
        error: 'Failed to generate tests from LLM service'
      })
      return
    }
  } catch (error) {
    console.error('Error in generate route:', error)
    res.status(500).json({
      error: 'Internal server error'
    })
  }
})